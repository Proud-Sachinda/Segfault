create view foreign_data_wrappers as
SELECT w.foreign_data_wrapper_catalog,
       w.foreign_data_wrapper_name,
       w.authorization_identifier,
       (NULL::character varying)::information_schema.character_data AS library_name,
       w.foreign_data_wrapper_language
FROM information_schema._pg_foreign_data_wrappers w;

alter table foreign_data_wrappers
  owner to postgres;

